# PlantsRecognition
A Random Forests approach for plant species recognition
